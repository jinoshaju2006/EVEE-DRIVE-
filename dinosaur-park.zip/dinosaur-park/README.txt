Dinosaur Park
A free 3D model kit from Shuriken Studio
https://shuriken.studio/kits/dinosaur-park

A free low-poly dinosaur park kit for Roblox Studio: 25 matching GLB models for a dinosaur theme park, a prehistoric survival game or a safari adventure. Dinosaurs include a T-rex, a triceratops, a long-neck sauropod and a stegosaurus, plus a raptor park set. The park runs from a dinosaur park gate and a fence kit to a safari visitor centre and a dinosaur hatchery. Visitors get around on a park monorail and a safari tour truck, so there is more than one way to see the animals. A fossil dig site and a T-rex skeleton display add a museum corner, and prehistoric plants and a lava volcano shape the land beyond the fences. Run it as a calm park tour, or let the dinosaurs loose and turn the visit into an escape. The dinosaurs are static models with no animations, ready to pose around the paddocks or to rig yourself.

25 models, as GLB (glTF 2.0) files:
  low-poly-t-rex.glb            Low-Poly T-Rex  https://shuriken.studio/models/characters/low-poly-t-rex
  low-poly-triceratops.glb      Low-poly Triceratops  https://shuriken.studio/models/characters/low-poly-triceratops
  low-poly-sauropod.glb         Low-Poly Sauropod  https://shuriken.studio/models/characters/low-poly-sauropod
  dinosaur-park-gate.glb        Dinosaur Park Gate  https://shuriken.studio/models/buildings/dinosaur-park-gate
  low-poly-spinosaurus.glb      Low-Poly Spinosaurus  https://shuriken.studio/models/characters/low-poly-spinosaurus
  dino-head-snack-kiosk.glb     Dino Head Snack Kiosk  https://shuriken.studio/models/buildings/dino-head-snack-kiosk
  prehistoric-plants-set.glb    Prehistoric Plants Set  https://shuriken.studio/models/nature/prehistoric-plants-set
  fossil-dig-site.glb           Fossil Dig Site  https://shuriken.studio/models/props/fossil-dig-site
  raptor-park-set.glb           Raptor Park Set  https://shuriken.studio/models/characters/raptor-park-set
  safari-viewing-tower.glb      Safari Viewing Tower  https://shuriken.studio/models/buildings/safari-viewing-tower
  pterosaur-park-set.glb        Pterosaur Park Set  https://shuriken.studio/models/characters/pterosaur-park-set
  dino-park-gift-shop.glb       Dino Park Gift Shop  https://shuriken.studio/models/buildings/dino-park-gift-shop
  safari-park-tour-truck.glb    Safari Park Tour Truck  https://shuriken.studio/models/vehicles/safari-park-tour-truck
  safari-visitor-centre.glb     Safari Visitor Centre  https://shuriken.studio/models/buildings/safari-visitor-centre
  dino-park-fence-kit.glb       Dino Park Fence Kit  https://shuriken.studio/models/kits/dino-park-fence-kit
  river-safari-boat.glb         River Safari Boat  https://shuriken.studio/models/vehicles/river-safari-boat
  dinosaur-hatchery.glb         Dinosaur Hatchery  https://shuriken.studio/models/props/dinosaur-hatchery
  low-poly-ankylosaurus.glb     Low-poly Ankylosaurus  https://shuriken.studio/models/characters/low-poly-ankylosaurus
  park-control-room.glb         Park Control Room  https://shuriken.studio/models/furniture/park-control-room
  prehistoric-lava-volcano.glb  Prehistoric Lava Volcano  https://shuriken.studio/models/scenery/prehistoric-lava-volcano
  park-monorail.glb             Park Monorail  https://shuriken.studio/models/vehicles/park-monorail
  low-poly-parasaurolophus.glb  Low-poly Parasaurolophus  https://shuriken.studio/models/characters/low-poly-parasaurolophus
  dino-paddock-gate.glb         Dino Paddock Gate  https://shuriken.studio/models/props/dino-paddock-gate
  low-poly-stegosaurus.glb      Low-Poly Stegosaurus  https://shuriken.studio/models/characters/low-poly-stegosaurus
  t-rex-skeleton-display.glb    T-Rex Skeleton Display  https://shuriken.studio/models/props/t-rex-skeleton-display

Using them
  Roblox Studio: Import 3D, choose a GLB, insert.
  Blender: File > Import > glTF 2.0.
  Unity, Godot, Unreal, three.js: import directly or through glTF.

Terms
  Free to use in any project, commercial games included: no account, no fee and no credit needed.
  Don't sell or share the model files themselves, alone or as a pack. They come as they are, with
  no warranty. LICENSE.txt has the short version; the full license is at https://shuriken.studio/legal/models
